import React,{ Fragment } from 'react';
import { StyleSheet, StatusBar } from 'react-native';
import AppNavigation from './src/router'
export default function App() {
  return (
    <Fragment>
      <StatusBar 
        translucent={true}
        backgroundColor="blue" 
        barStyle="light-content" />
      <AppNavigation/>
    </Fragment>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
