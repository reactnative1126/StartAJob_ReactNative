import React from 'react'
import { 
  View,
  Text,
  StyleSheet,
  ScrollView,
  Animated,
  StatusBar,
  Image,
  SafeAreaView
} from 'react-native'
import { getStatusBarHeight } from 'react-native-status-bar-height';
import * as Device from 'expo-device'

// Local components
import Header from './../../components/Header'
import Search from './../../components/Search'
import Card from './../../components/Card'
import NoOpenJobAlert from './NoOpenJobAlert'
import WorkAreaNotSet from './WorkAreaNotSet'
import CutomButton from './../../components/Button'
import NoJobIcon from './../../../assets/no-jobs-icon.png'


// Images
import Background from './../../../assets/background-pattern-gray.png'
import BackgroundImage from './../../components/BackgroundImage'
// Config
import { Color, normalize } from './../../global'
import { TouchableOpacity } from 'react-native-gesture-handler'

/**
 * Jobs Component
 *
 * @version 1.0.0
 * @author [Ashwani Arya](https://github.com/ashwaniarya)
 */

class Jobs extends React.Component {
  
  constructor(props) {
    super(props)

    const scrollAnim = new Animated.Value(0)
    const offsetAnim = new Animated.Value(0)

    this.state = {
      scrollAnim,
      offsetAnim,
      clampedScroll: Animated.diffClamp(
        Animated.add(
          scrollAnim.interpolate({
            inputRange: [ 0, 1 ],
            outputRange: [ 0, 1 ],
            extrapolateLeft: 'clamp'
          }),
          offsetAnim
        ),
        0,
        112
      )
    };
  }
  
  componentDidMount(){
    console.log(Device)
  }
   renderJobCards = () => {
    return <View>
      <Card
          onPress={()=>{
            this.props.navigation.navigate('ChatScreen',{
              jobState: "BID_NOT_PLACED",
              varified: false
            })
          }} 
          jobState="NEW_MESSAGE"
          address= "Saint Mark St 124f, LA, CA, 0421431"
          newMessageCount= {5}
          jobTitle="Build website on WordPress using PHP"
          userName="John Doe"
          description="Hello John! I have done a couple of similar project on"
          isRead= { false }
          timestamp='2 min'
          distance = '0.5 Km'
          jobType= "FULL_TIME"
          category= {'Web Design'}
          subCategories= "WordPress, HTML/CSS"
        />
        <Card 
          onPress={()=>{
            alert('Job Card')
          }}
          jobTitle="Build website on WordPress using PHP"
          userName="John Doe"
          timestamp='2 min'
          address= "Saint Mark St 124f, LA, CA, 0421431"
          description="Hello John! I have done a couple of similar project on"
          jobType= "FULL_TIME"
          distance = '0.5 Km'
          category= {'Web Design'}
          subCategories= "WordPress, HTML/CSS"
        />
        <Card
          onPress={()=>{
            alert('Job Card')
          }} 
          jobTitle="Build website on WordPress using PHP"
          userName="John Doe"
          description="Hello John! I have done a couple of similar project on"
          isRead= { true }
          address= "Saint Mark St 124f, LA, CA, 0421431"
          distance = '0.5 Km'
          timestamp='2 min'
          jobType= "FULL_TIME"
          category= {'Web Design'}
          subCategories= "WordPress, HTML/CSS"
          separater= { false }
        />
        <Card 
          onPress={()=>{
            alert('Job Card')
          }}
          jobState="NEW_JOB"
          jobTitle="Build website on WordPress using PHP"
          description= "Need a professional WordPress developer to create"
          userName="John Doe"
          address= "Saint Mark St 124f, LA, CA, 0421431"
          distance = '0.5 Km'
          isRead= { false }
          timestamp='2 min'
          jobType= "FULL_TIME"
          category= {'Web Design'}
          subCategories= "WordPress, HTML/CSS"
        />
        <Card
          onPress={()=>{
            alert('Job Card')
          }} 
          jobState="BID_ACCEPTED"
          bid = {{
            acceptedPrice: 1000,
            proposedPrice: 1000,
            days: 0
          }}
          onPress={()=>{
            this.props.navigation.navigate('ChatScreen',{
              jobState: "BID_ACCEPTED",
              varified: true,
              oIcon: true
            })
          }}
          description="Hello John! I have done a couple of similar project on"
          jobTitle="Build website on WordPress using PHP"
          userName="John Doe"
          distance = '0.5 Km'
          isRead= { false }
          timestamp='2 min'
          jobType= "ONE_TIME"
          category= {'Web Design'}
          subCategories= "WordPress, HTML/CSS, CRM, JavaScript"
        />
        <Card
          onPress={()=>{
            alert('Job Card')
          }}
          jobState="BID_PLACED"
          bid = {{
            acceptedPrice: 1000,
            proposedPrice: 0,
            days: 0
          }}
          description="Hello John! I have done a couple of similar project on"
          jobTitle="Build website on WordPress using PHP"
          userName="John Doe"
          distance = '0.5 Km'
          isRead= { false }
          timestamp='2 min'
          jobType= "ONE_TIME"
          category= {'Web Design'}
          subCategories= "WordPress, HTML/CSS, CRM, JavaScript"
        />
        <Card
          onPress={()=>{
            alert('Job Card')
          }} 
          jobState="BID_COMPLETED_RELEASED"
          bid = {{
            acceptedPrice: 1000,
            proposedPrice: 0,
            days: 0
          }}
          description="Hello John! I have done a couple of similar project on"
          jobTitle="Build website on WordPress using PHP"
          userName="John Doe"
          distance = '0.5 Km'
          isRead= { false }
          timestamp='2 min'
          jobType= "ONE_TIME"
          category= {'Web Design'}
          subCategories= "WordPress, HTML/CSS, CRM, JavaScript"
        />
    </View>
  }

  render(){
    let changeTop = undefined
    // To animate top header
    
    return(<View  style={[ styles.container ]}>
      
      {/* Background Image*/}
      <BackgroundImage />
      {/* Animated Header*/}
      <Header 
        clampedScroll={ this.state.clampedScroll }
        bottomComponent={<Search 
          style={{
            backgroundColor: '#FFF',
          }}
        />}
        mainText = "Jobs"
      />
      
      { !this.state.noOpenJobs && !this.state.noWorkArea && <Animated.ScrollView
        scrollEventThrottle={8}
        style= {{
          paddingTop: 0,
        }}
        contentContainerStyle={{
          paddingTop: getStatusBarHeight()+120
        }}
        onScroll={Animated.event(
          [{ nativeEvent: {
               contentOffset: {
                 y: this.state.scrollAnim
               }
             }
           }],{
              useNativeDriver: true
           }
        )}
        onMomentumScrollEnd= {() =>{ 
          
        }}
      > 
       {/* Render all jobs card */}
       { this.renderJobCards() }
       <CutomButton
          style={{
            borderRadius: 4,
            paddingVertical: 10,
            margin: 5
          }}
          onPress={ ()=>{
            this.setState({ noWorkArea: true })
          }}
          fontWeight={'300'}
          backgroundColor= { Color.color7 }
          title={'No work area alert'}/>
      <CutomButton
        style={{
          borderRadius: 4,
          paddingVertical: 10,
          margin: 5
        }}
        onPress={ ()=>{
          this.setState({ noOpenJobs: true })
        }}
        fontWeight={'300'}
        backgroundColor= { Color.color7 }
        title={'No jobs found'}/>
      </Animated.ScrollView> }
      { this.state.noOpenJobs && <View style={{
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
      }}>
        {/* Remove this button */}
        <CutomButton
          style={{
            borderRadius: 4,
            paddingVertical: 10,
            margin: 5,
            width: 200,
            opacity: 0.4
          }}
          onPress={ ()=>{
            this.setState({ noOpenJobs: false })
          }}
          fontWeight={'300'}
          backgroundColor= { '#d4d4d4' }
          title={'Go back ( For demo only)'}/>
        <NoOpenJobAlert />
      </View> }
      { this.state.noWorkArea && <View 
        style={{
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
      }}>
        {/* Remove this button */}
        <CutomButton
        style={{
          borderRadius: 4,
          paddingVertical: 10,
          margin: 5,
          width: 200,
          opacity: 0.4
        }}
        onPress={ ()=>{
          this.setState({ noWorkArea: false })
        }}
        fontWeight={'300'}
        backgroundColor= { '#d4d4d4' }
        title={'Go back ( For demo only)'}/>
        <WorkAreaNotSet 
          onPressConfigure={() => {
            alert('hello')
          }}
        />
      </View> }
    </View >)
  }
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#E3E3E3',
    position: 'relative',
    flex: 1
  },
  searchContainer : {
    paddingHorizontal: 15,
    backgroundColor: '#FAFAFA'
  },
  shadow : Platform.OS === "ios" ? {
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  } : {
    elevation: 5
  }
})
export default Jobs