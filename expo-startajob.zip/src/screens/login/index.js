import React from 'react'
import {
  View,
  Text,
  StyleSheet,
  Image,
  TextInput,
  ScrollView,
  KeyboardAvoidingView,
  Dimensions
} from 'react-native'
import { TouchableOpacity } from 'react-native-gesture-handler'
import PropType from 'prop-types'

// Local imports
// Icons or Images
import Logo from './../../../assets/logo.png'
import LoginIcon from './../../../assets/login.png'
import FacebookIcon from './../../../assets/facebook_icon.png'
import SignIn from './../../../assets/sign-in.png'


// Components
import CutomButton from './../../components/Button'

// Globals
import { Color, normalize } from './../../global'
import { Platform } from '@unimodules/core';

/**
 * Login Component
 *
 * @version 1.0.0
 * @author [Ashwani Arya](https://github.com/ashwaniarya)
 */

 let { height } = Dimensions.get("window")

class Login extends React.Component {

  state = {
    email: '',
    password: ''
  }

  onPressAlert = () => {
    alert("I am a button")
  }

  componentDidMount(){
  }

  render(){
    return(
    <KeyboardAvoidingView style={styles.container} behavior="height">
      <View style={styles.top}>
        <View style={{ alignItems: 'center' }}>
          <Image 
            source={Logo}
            style={styles.logoImage}
          />
          <View style={{ flexDirection:'row', justifyContent: 'center' }}>
            <Text style={{ fontSize: 30, color: Color.color6 }}>Start</Text>
            <Text style={{ fontSize: 30, color: Color.color7 }}>A</Text>
            <Text style={{ fontSize: 30, color: Color.color6 }}>Job</Text>
          </View>
        </View>
      </View>
      <View style={styles.middle}>
        <View style={{ marginBottom: 20 }}>
          <Text style={{ color: "#02245D", fontSize: 17, fontWeight: 'bold' }}>Please enter your login credentials</Text>
        </View>
        <KeyboardAvoidingView>
          <TextInput 
            placeholder= { 'Your email address' }
            placeholderTextColor= "#121212"
            style= { styles.textInput }
          />
          <TextInput 
            placeholder= { 'Your password' }
            placeholderTextColor= "#121212"
            secureTextEntry= {true}
            style= { styles.textInput }
          />
          
          <View style={{ marginTop: 10 }}>
            <CutomButton
              style={{
                borderRadius: 4,
              }}
              onPress={ ()=> {
                this.props.navigation.navigate('Screen')
                //alert(Dimensions.get("screen").height)
              }}
              logo={LoginIcon}
              fontWidth={'100'}
              fontSize={17}
              backgroundColor= { Color.primary }
              title={'Login'}/>
          </View>
          <View style={{ flexDirection: 'row', justifyContent: 'center' }}>
            <View style={{ flexDirection: 'row' }}>
              <View style={{ marginHorizontal: 10, flexDirection: 'row', alignItems: 'center' }}>
                <TouchableOpacity 
                  onPress={this.onPressAlert}
                  style={{ justifyContent: 'center' }}>
                  <Text style={{ 
                    textDecorationLine: 'underline', 
                    color: '#02245D'
                  }}>Forgot your password?</Text>
                </TouchableOpacity>
              </View>
              <View 
                style={{ 
                  marginHorizontal: 5, 
                  flexDirection: 'row', 
                  alignItems: 
                  'center' }}
              >
                <Text 
                  style={{ 
                    color: Color.color4,
                    textDecorationLine: 'underline' }}
                  >|</Text></View>
              <View 
                style={{ 
                  marginHorizontal: 10, 
                  flexDirection: 'row', 
                  alignItems: 'center' }}
              >
                <Text 
                  style={{ 
                    marginRight: 5,
                    color: Color.color4
                  }}>Login via</Text>
                {/* Facebook login button */}
                <TouchableOpacity 
                  onPress={this.onPressAlert}
                >
                  <Image source={FacebookIcon} style={{ height: 32, width: 32 }}/>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </KeyboardAvoidingView>
        <View 
          style={styles.signinContainer}>
        <View>
          <View style={{ alignItems: 'center' }}>
            <Text 
              style={{ 
                textDecorationLine: 'underline', 
                marginRight: 5,
                color: Color.color4
              }}>New Here?</Text>
          </View>
          <View style={{ flexDirection: 'row' }}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Image source={SignIn} style={{ height: 14, width: 14, marginHorizontal: 5 }}/>
              <TouchableOpacity style={{ justifyContent: 'center' }}>
                <Text 
                  onPress={this.onPressAlert}
                  style={{ 
                    textDecorationLine: 'underline', 
                    color: Color.primary,
                    fontSize: 17,
                    fontWeight: 'bold'
                  }}>Create an Account</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </View>
      </View>
    </KeyboardAvoidingView>)
  }
}

// Props Types
Login.propTypes = {

}

// Default Props
Login.defaultProps = {
  title: 'No name'
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white'
  },
  top: {
    flex: 2,
    justifyContent: 'center',
    alignItems: 'center'
  },
  middle: {
    flex: 3,
    paddingHorizontal: 15
  },
  bottom: {
    alignItems: 'center',
    justifyContent: 'center'
  },
  logoImage: {
    height: 84,
    width: 84
  },
  textInput : {
    borderWidth: 2,
    borderColor: '#E3E3E3',
    borderRadius: 4,
    paddingHorizontal: 15,
    paddingVertical: Platform.OS === "ios"? 12 :8,
    fontSize: 13,
    color: '#121212',
    marginBottom: 10,
    backgroundColor: '#E3E3E3'
  },
  signinContainer : {
    marginTop: Dimensions.get("window").height > 600 ? 40 : 10,
    alignItems: 'center',
    justifyContent: 'center' 
  }
});

export default Login