import React, { Component } from "react";
import { Text, Dimensions, TextInput, View, StyleSheet, TouchableOpacity, StatusBar } from "react-native";
const xmlHeader = '<?xml version="1.0" encoding="utf-8"?>';
const xmlRequest = '<Envelope xmlns="http://schemas.xmlsoap.org/soap/envelope/"><Body><Login xmlns="http://tempuri.org/"><UserName>dan</UserName><Password>123456</Password><IPs>209.95.60.92</IPs></Login></Body></Envelope>'
    
class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
      visible: false,
      color: '',
      message: ''
    };
  }
  
  onLogin() {
    if (this.state.username == '') {
      this.setState({visible: true, color: '#FF0000', message: 'The username is not inputed'});
      return;
    }
    if (this.state.password == '') {
      this.setState({visible: true, color: '#FF0000', message: 'The password is not inputed'});
      return;
    }
    fetch('http://isapi.icu-tech.com/ICUTech-test.dll/soap/IICUTech', {
      method: 'POST',
      headers: {
        'Authorization': 'Basic YWRtaW53ZWJzaXRlOk5mbjM5Zm5BQWQyMw==',
        'Content-Type': 'text/xml',
      },
      body: xmlHeader + xmlRequest,
    }).then((response) => response.text())
      .then((response) => {
        var responseJSON = response.split('{')[1].split('}')[0]
        var ResultCode = responseJSON.split('"ResultCode":')[1].split(',')[0]
        var ResultMessage = responseJSON.split('"ResultMessage":"')[1].split('"')[0] + '\n' + responseJSON
        if(ResultCode == -1) 
          this.setState({visible: true, color: '#FF0000', message: ResultMessage});
        else
          this.setState({visible: true, color: '#00FF00', message: ResultMessage});
    }).catch((error) => {
      this.setState({visible: true, color: '#FF0000', message: 'Login Request Failed'});
      return
    });

  }
  render() {
    return (
      <View style={styles.contentContainer}>
        <StatusBar backgroundColor='#fff' barStyle='dark-content' />
          <View style={{ width: DEVICE_WIDTH, alignItems: 'center', justifyContent: 'center', marginTop: 50 }}>
            <Text style={{ color: '#000', fontSize: 24, fontWeight: 'bold' }}>{"Login to Continue"}</Text>
          </View>
          <View style={{ width: DEVICE_WIDTH * 0.8, marginLeft: DEVICE_WIDTH * 0.1, marginTop: 20 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Text style={{ color: '#808080', fontSize: 12, marginLeft: 10 }}>{"USER NAME"}</Text>
            </View>
            <View>
              <TextInput
                style={{ backgroundColor: 'transparent', width: DEVICE_WIDTH * 0.8, height: 40, paddingLeft: 10, color: '#000'}}
                selectionColor="#009788"
                onChangeText={username => this.setState({ username })}
                autoCapitalize="none"
                underlineColorAndroid="transparent"
              />
            </View>
            <View style={{ height: 1, width: DEVICE_WIDTH * 0.8, backgroundColor: '#808080' }} />
          </View>
          <View style={{ width: DEVICE_WIDTH * 0.8, marginLeft: DEVICE_WIDTH * 0.1, marginTop: 20 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Text style={{ color: '#808080', fontSize: 12, marginLeft: 10 }}>{"PASSWORD"}</Text>
            </View>
            <View>
              <TextInput
                style={{ backgroundColor: 'transparent', width: DEVICE_WIDTH * 0.8, height: 40, paddingLeft: 10, color: '#000' }}
                secureTextEntry
                selectionColor="#009788"
                onChangeText={password => this.setState({ password })}
                autoCapitalize="none"
                underlineColorAndroid="transparent"
              />
            </View>
            <View style={{ height: 1, width: DEVICE_WIDTH * 0.8, backgroundColor: '#808080' }} />
          </View>
          <View style={{ width: DEVICE_WIDTH, height: 40, alignItems: 'center', justifyContent: 'center', marginTop: 40 }}>
            <TouchableOpacity style={{ width: DEVICE_WIDTH * 0.8, height: 40, borderRadius: 25, backgroundColor: '#DE5859', alignItems: 'center', justifyContent: 'center' }}
              onPress={() => this.onLogin()}>
              <Text style={{ color: '#fff', fontSize: 16, fontWeight: 'bold' }}>{"LOGIN"}</Text>
            </TouchableOpacity>
          </View>
          <View style={{ width: DEVICE_WIDTH, justifyContent: 'center', alignItems: 'center', marginTop: 30 }}>
            <Text style={{ color: '#000', fontSize: 14, }}>{"- or -"}</Text>
          </View>
          <View style={{ flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginTop: 30 }}>
            <Text style={{ color: '#000', fontSize: 14, }}>{"Don't have an account yet?"}</Text>
            <TouchableOpacity onPress={() => alert('This is sign up')}>
              <Text style={{ color: '#DE5859', fontSize: 14, textDecorationLine: 'underline', fontWeight: 'bold' }}>{" Sign Up "}</Text>
            </TouchableOpacity>
          </View>
        <View style={[styles.container, this.state.visible ? styles.absolute : '', this.state.visible ? styles.show : styles.hide]}>
          <View style={{width: '100%', height: '100%', backgroundColor: '#00000098', zIndex: 99}} />
          <View style={[this.state.visible ? styles.absolute : '', {zIndex: 100, top: '40%', width: DEVICE_WIDTH * 0.8, height: 150, borderRadius: 10, backgroundColor: '#FFFFFF', justifyContent: 'center', alignItems: 'center'}]}>
            <Text style={{color: this.state.color, marginLeft: 10, marginTop: 20}}>{this.state.message}</Text>
            <TouchableOpacity style={{ top: 20, width: DEVICE_WIDTH * 0.3, height: 40, borderRadius: 15, backgroundColor: '#AAAAAA', alignItems: 'center', justifyContent: 'center' }}
              onPress={() => this.setState({visible: false})}>
              <Text style={{ color: '#fff', fontSize: 16, fontWeight: 'bold' }}>{"OK"}</Text>
            </TouchableOpacity>
          </View>
        </View>   
      </View>        
    );
  }
}
const DEVICE_WIDTH = Dimensions.get('window').width;
const styles = StyleSheet.create({
  contentContainer: {
    width: '100%',
    height: '100%',
    backgroundColor: '#fff',
  },
  container: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  show: {
    display: 'flex'
  },
  hide: {
    display: 'none'
  },
  absolute: {
    position: 'absolute'
  }
});
export default Login;
